Hooks.once("setup", () => {
    game.wfrp4e.config.magicLores["ice"] = "Ice"; 
    game.wfrp4e.config.magicWind["ice"] = "Ice"; 
    
    game.wfrp4e.config.loreEffectDescriptions["ice"] = "You inflict 1 @Condition[Chilled] Condition on any target successfully affected by a spell from the Lore of Ice. A target may only ever have a single @Condition[Chilled] Condition gained in this manner at any one time.<br>For every @Condition[Chilled] Condition currently affecting any creature within a number of yards equal to your Willpower Bonus, you gain a +10 bonus to your Channelling (Ice) and Language (Magick) Tests.";

    // --- CLEANUP 1: Возвращаем твой старый надежный метод сортировки ---
    const oldConditions = game.wfrp4e.config.conditions;
    const newConditions = {};
    
    for (let key in oldConditions) {
        if (key === "chill") continue; 
        if (key === "prone") newConditions["icechill"] = "Chilled"; 
        newConditions[key] = oldConditions[key];
    }
    if (!newConditions["icechill"]) newConditions["icechill"] = "Chilled";
    game.wfrp4e.config.conditions = newConditions; 
    
    game.wfrp4e.config.conditionDescriptions["icechill"] = `
<p>Your body freezes to the bone, your joints lose mobility, your muscles stiffen, and your reflexes dull.</p>
<p>For each <strong>Chilled</strong> Condition you have, you suffer a -10 penalty to Weapon Skill, Ballistic Skill, Strength, Agility, and Dexterity Tests, and your Movement is reduced by 1 (to a minimum of 1). Chilled Conditions stack without limit. If any profile Characteristic is reduced to 0 by this Condition, you are physically incapable of performing Actions associated with it.</p>
<p><strong>Removing Chilled Conditions</strong></p>
<p><strong>Warming Up (Action):</strong> On your turn, you may spend an Action to rigorously rub your limbs and jump in place. Make a Challenging (+0) Athletics or Endurance Test. A success removes 1 Chilled Condition, plus 1 additional Condition for each +1 SL.</p>
<p><strong>External Heat:</strong> Standing adjacent to an intense heat source or successfully consuming a measure of highly potent alcohol removes all Chilled Conditions. If you gain an <strong>Ablaze</strong> Condition, it immediately removes 1 Chilled Condition (the two Conditions cancel each other out).</p>
`;

    // ИСПРАВЛЕНИЕ КНОПКИ: Добавлены await перед addCondition и setFlag
    game.wfrp4e.config.loreEffects["ice"] = {
        name: "Lore of Ice",
        img: "modules/wfrp4e-unofficial-compendium/assets/icons/Lore-of-Ice.jpg",
        flags: { wfrp4e: { lore: true } },
        system: {
            transferData: { type: "target" },
            scriptData: [{
                trigger: "immediate",
                label: "@effect.name",
                script: `
                    let hasIceMagic = this.actor.itemTypes.talent.some(i => i.name.includes("Arcane Magic (Ice)"));
                    let hasLoreChill = this.actor.getFlag("wfrp4e", "loreIceChill");
                    if (!hasIceMagic && !hasLoreChill) {
                        await this.actor.addCondition("icechill");
                        await this.actor.setFlag("wfrp4e", "loreIceChill", true);
                    }
                `,
                options: { deleteEffect: true }
            }]
        }
    };

let chillEffect = {
        id: "icechill", 
        name: "Chilled",
        img: "modules/wfrp4e-unofficial-compendium/assets/icons/chilled.svg", 
        icon: "modules/wfrp4e-unofficial-compendium/assets/icons/chilled.svg", 
        statuses: ["icechill"], 
        flags: { wfrp4e: { condition: true, value: 1 } }, 
        system: {
            condition: { value: 1, numbered: true },
            scriptData: [
                {
                    label: "Chilled Penalties",
                    // ИСПРАВЛЕНИЕ 1: Меняем триггер. Теперь штраф накладывается ДО того, как посчитаются навыки
                    trigger: "prePrepareData", 
                    script: `
                        let stacks = this.effect.conditionValue || this.effect.system?.condition?.value || 1; 
                        let penalty = stacks * -10;
                        let stats = ["ws", "bs", "s", "ag", "dex"];
                        
                        for (let stat of stats) {
                            // ИСПРАВЛЕНИЕ 2: Модифицируем только modifier. 
                            // Система сама безопасно пересчитает value и спустит его в навыки
                            this.actor.system.characteristics[stat].modifier += penalty;
                        }
                        
                        this.actor.system.details.move.value -= stacks;
                        if (this.actor.system.details.move.value < 1) this.actor.system.details.move.value = 1;
                    `
                },
                {
                    label: "Clear Lore Flag",
                    trigger: "deleteEffect",
                    script: `if (this.actor.getFlag("wfrp4e", "loreIceChill")) this.actor.unsetFlag("wfrp4e", "loreIceChill");`
                }
            ]
        }
    };

    // --- CLEANUP 2: Remove old "chill" from Token HUD Menu ---
    CONFIG.statusEffects = CONFIG.statusEffects.filter(e => e.id !== "chill");
    if (game.wfrp4e?.config?.statusEffects) {
        game.wfrp4e.config.statusEffects = game.wfrp4e.config.statusEffects.filter(e => e.id !== "chill");
    }

    let proneIndex = CONFIG.statusEffects.findIndex(e => e.id === "deafened");
    if (proneIndex !== -1) CONFIG.statusEffects.splice(proneIndex, 0, chillEffect);
    else CONFIG.statusEffects.push(chillEffect);

    if (game.wfrp4e?.config?.statusEffects) {
        let wfrpProneIndex = game.wfrp4e.config.statusEffects.findIndex(e => e.id === "deafened");
        if (wfrpProneIndex !== -1) game.wfrp4e.config.statusEffects.splice(wfrpProneIndex, 0, chillEffect);
        else game.wfrp4e.config.statusEffects.push(chillEffect);
    }
});

async function reduceOrRemove(effectDocument, amountToRemove) {
    let currentVal = effectDocument.conditionValue ?? effectDocument.system?.condition?.value ?? effectDocument.flags?.wfrp4e?.value ?? 1;
    let newVal = currentVal - amountToRemove;
    
    if (newVal <= 0) {
        await effectDocument.delete();
    } else {
        await effectDocument.update({ 
            "system.condition.value": newVal,
            "flags.wfrp4e.value": newVal
        });
    }
}

Hooks.on("preCreateActiveEffect", (effect, data, options, userId) => {
    if (game.user.id !== userId) return;
    const actor = effect.parent;
    if (!actor) return;

    const isAblaze = effect.statuses?.has("ablaze") || effect.name === "Ablaze";
    const isChill = effect.statuses?.has("icechill") || effect.name === "Chilled";

    if (isAblaze) {
        let existingChill = actor.effects.find(e => e.statuses?.has("icechill") || e.name === "Chilled");
        if (existingChill) {
            let existingVal = existingChill.conditionValue ?? existingChill.system?.condition?.value ?? 1;
            let incomingVal = effect.system?.condition?.value ?? 1;
            let reduction = Math.min(existingVal, incomingVal);

            if (reduction > 0) {
                reduceOrRemove(existingChill, reduction);
                let leftover = incomingVal - reduction;
                
                if (leftover <= 0) {
                    ui.notifications.info(`Ice and Fire instantly neutralized each other!`);
                    return false; 
                } else {
                    effect.updateSource({ "system.condition.value": leftover, "flags.wfrp4e.value": leftover });
                }
            }
        }
    }

    if (isChill) {
        let existingAblaze = actor.effects.find(e => e.statuses?.has("ablaze") || e.name === "Ablaze");
        if (existingAblaze) {
            let existingVal = existingAblaze.conditionValue ?? existingAblaze.system?.condition?.value ?? 1;
            let incomingVal = effect.system?.condition?.value ?? 1;
            let reduction = Math.min(existingVal, incomingVal);

            if (reduction > 0) {
                reduceOrRemove(existingAblaze, reduction);
                let leftover = incomingVal - reduction;
                
                if (leftover <= 0) {
                    ui.notifications.info(`Fire and Ice instantly neutralized each other!`);
                    return false; 
                } else {
                    effect.updateSource({ "system.condition.value": leftover, "flags.wfrp4e.value": leftover });
                }
            }
        }
    }
});

Hooks.on("preUpdateActiveEffect", (effect, changes, options, userId) => {
    if (game.user.id !== userId) return;
    const actor = effect.parent;
    if (!actor) return;

    let newVal = changes.system?.condition?.value;
    if (newVal === undefined) return;

    const isAblaze = effect.statuses?.has("ablaze") || effect.name === "Ablaze";
    const isChill = effect.statuses?.has("icechill") || effect.name === "Chilled";

    if (isAblaze) {
        let existingChill = actor.effects.find(e => e.statuses?.has("icechill") || e.name === "Chilled");
        if (existingChill) {
            let existingChillVal = existingChill.conditionValue ?? existingChill.system?.condition?.value ?? 1;
            let oldAblazeVal = effect.conditionValue ?? effect.system?.condition?.value ?? 1;
            let addedBlaze = newVal - oldAblazeVal;
            
            if (addedBlaze > 0) {
                let reduction = Math.min(existingChillVal, addedBlaze);
                reduceOrRemove(existingChill, reduction);
                
                let actualNewAblazeVal = oldAblazeVal + (addedBlaze - reduction);
                changes.system.condition.value = actualNewAblazeVal;
                
                ui.notifications.info(`Additional stacks neutralized!`);
                if (actualNewAblazeVal <= 0) {
                    // ИСПРАВЛЕНИЕ ДЛЯ V14: Безопасное удаление после завершения хука
                    setTimeout(() => effect.delete(), 0);
                    return false;
                }
            }
        }
    }

    if (isChill) {
        let existingAblaze = actor.effects.find(e => e.statuses?.has("ablaze") || e.name === "Ablaze");
        if (existingAblaze) {
            let existingAblazeVal = existingAblaze.conditionValue ?? existingAblaze.system?.condition?.value ?? 1;
            let oldChillVal = effect.conditionValue ?? effect.system?.condition?.value ?? 1;
            let addedChill = newVal - oldChillVal;
            
            if (addedChill > 0) {
                let reduction = Math.min(existingAblazeVal, addedChill);
                reduceOrRemove(existingAblaze, reduction);
                
                let actualNewChillVal = oldChillVal + (addedChill - reduction);
                changes.system.condition.value = actualNewChillVal;
                
                ui.notifications.info(`Additional stacks neutralized!`);
                if (actualNewChillVal <= 0) {
                    // ИСПРАВЛЕНИЕ ДЛЯ V14: Безопасное удаление после завершения хука
                    setTimeout(() => effect.delete(), 0);
                    return false;
                }
            }
        }
    }
});

Hooks.on("wfrp4e:preRollTest", (testData) => {
    if (testData.type !== "cast" && testData.type !== "channelling") return;
    
    let isIceMagic = testData.item?.system?.lore?.value === "ice" || testData.item?.name?.toLowerCase().includes("ice");
    if (!isIceMagic) return;

    let actor = testData.actor;
    if (!actor) return;
    
    let wpb = actor.system.characteristics.wp.bonus; 
    let token = actor.getActiveTokens()[0] || canvas.tokens.controlled[0];
    if (!token) return;

    let chillStacks = 0;
    let targets = canvas.tokens.placeables.filter(t => t.id !== token.id && t.actor);
    
    for (let t of targets) {
        let distanceInYards = canvas.grid.measurePath([{x: token.center.x, y: token.center.y}, {x: t.center.x, y: t.center.y}]).distance;
        
        if (distanceInYards <= wpb) {
            let chillCondition = t.actor.effects.find(e => e.statuses?.has("icechill") || e.name === "Chilled");
            if (chillCondition) {
                chillStacks += (chillCondition.conditionValue || chillCondition.system?.condition?.value || 1);
            }
        }
    }

    if (chillStacks > 0) {
        let bonus = chillStacks * 10;
        testData.modifier += bonus;
        
        if (!testData.modifierOptions) testData.modifierOptions = [];
        testData.modifierOptions.push({ label: "Deadly Chill (Lore of Ice)", value: bonus });
        ui.notifications.info(`Deadly Chill bonus applied: +${bonus} (${chillStacks} stacks nearby).`);
    }
});